function result=Q2n (im)
    result=rgb2gray(im);
    result=fliplr(result)
end
