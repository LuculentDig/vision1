function die_number=dice()
    die_number=randi([1 6]);
end


