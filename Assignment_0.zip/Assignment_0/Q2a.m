function result=Q2a (im)
    result=rgb2gray(im);
    result=imcomplement(result)
end
