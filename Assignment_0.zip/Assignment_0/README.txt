Name: Wenyuan Wu
EID: ww6767

Part1: Q1.2.txt & Q1.3.txt
Part2: I wrote a function for each question. And I called them in part3.m
	Just run part3.m and it will give you the results.